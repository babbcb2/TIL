from django.contrib import admin
from .models import *

admin.site.register(StudentUser)
admin.site.register(TotalCurriculum)
admin.site.register(SpecDetail)
admin.site.register(CustomPeriod)