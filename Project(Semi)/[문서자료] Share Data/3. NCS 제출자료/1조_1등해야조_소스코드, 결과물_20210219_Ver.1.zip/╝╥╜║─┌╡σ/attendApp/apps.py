from django.apps import AppConfig


class AttendappConfig(AppConfig):
    name = 'attendApp'
